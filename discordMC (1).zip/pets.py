pets = {
	'common': [
		'wolf',
		'tiger'
	],
	'uncommon': [
		'sheep'
	],
	'rare': [
		'skeleton'
	],
	'epic': [
		'whale'
	],
	'legendary': [
		'spirit'
	],
	'mythic': [
		'dev'
	]
}
chances = [
	['common', 40],
	['uncommon', 20],
	['rare', 5],
	['epic', 1],
	['legendary', 0.1],
	['mythic', 0.005]
]