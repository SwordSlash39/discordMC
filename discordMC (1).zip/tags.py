Requires_crafting_table = [
  'discord:wooden_pickaxe',
  'discord:stone_pickaxe',
  'discord:iron_pickaxe',
  'discord:diamond_pickaxe',
  'discord:obsidian_pickaxe',
  'discord:wooden_axe',
  'discord:stone_axe',
  'discord:iron_axe',
  'discord:diamond_axe',
  'discord:obsidian_axe',
  'discord:wooden_sword',
  'discord:stone_sword',
  'discord:iron_sword',
  'discord:diamond_sword',
  'discord:obsidian_sword',
  'discord:undead_sword',
  'discord:iron_armor',
  'discord:diamond_armor',
  'discord:obsidian_armor',
  'discord:iron_shield',
  'discord:diamond_shield',
  'discord:obsidian_shield',
  'discord:bow',
  'discord:explosive_bow',
  'discord:undead_bow',
  'discord:netherite_ingot', 
  "discord:netherite_pickaxe", 
  "discord:netherite_axe", 
  "discord:netherite_sword"
]

Requires_portal_table = [
  'discord:nether_portal', 
  "discord:end_portal"
]

Undead = [
  'discord:zombie',
  'discord:skeleton',
  'discord:zombie_pigman'
]

Bed_explode_dimensions = [
	'discord:nether',
	'discord:the_end'
]
