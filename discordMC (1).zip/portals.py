warps = {
  'nether': ['discord:nether_portal', 'discord:nether'],
  'the_end': ['discord:end_portal', 'discord:the_end'],
  'end': ['discord:end_portal', 'discord:the_end']
}