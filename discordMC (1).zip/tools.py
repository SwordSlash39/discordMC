numerals = {
	'M': 1000,
	'CM': 900,
	'D': 500,
	'CD': 400,
	'C': 100,
	'XC': 90,
	'L': 50,
	'XL': 40,
	'X': 10,
	'IX': 9,
	'V': 5,
	'IV': 4,
	'I': 1
}

def convert_to_roman(num: int):
	to_return = ''
	for roman, decimal in numerals.items():
		while num >= decimal:
			to_return += roman
			num -= decimal
	return to_return


def convert_to_integer(roman: str):
	to_return = 0
	chars = []
	for char in roman:
		chars.append(char)
	while len(chars) != 0:
		try:
			chars[1] = chars[1]
		except IndexError:
			to_return += numerals[chars[0]]
			chars.pop(0)
		else:
			if numerals[chars[1]] > numerals[chars[0]]:
				to_return += numerals[chars[1]] - numerals[chars[0]]
				chars.pop(0)
				chars.pop(0)
			else:
				to_return += numerals[chars[0]]
				chars.pop(0)
	return to_return
